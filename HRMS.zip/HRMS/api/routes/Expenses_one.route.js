const expensesController = require("../controllers/Expenses.controller")
const express = require("express");
const router = express.Router();

// router.route('/create')
//     .post(expensesController.addData)
 
module.exports = router;                                                                                                                     